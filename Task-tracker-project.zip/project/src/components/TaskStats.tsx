import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { Task } from '../types';
import { isAfter, isBefore, startOfToday } from 'date-fns';

interface TaskStatsProps {
  tasks: Task[];
}

export function TaskStats({ tasks }: TaskStatsProps) {
  const completedTasks = tasks.filter(task => task.completed).length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

  const today = startOfToday();
  const overdueTasks = tasks.filter(
    task => !task.completed && isBefore(new Date(task.dueDate), today)
  ).length;

  const upcomingTasks = tasks.filter(
    task => !task.completed && isAfter(new Date(task.dueDate), today)
  ).length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-lg p-4"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-500 bg-opacity-20 rounded-lg">
            <CheckCircle2 className="w-6 h-6 text-green-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Completion Rate</h3>
            <p className="text-2xl font-bold text-green-400">{completionRate}%</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-lg p-4"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-yellow-500 bg-opacity-20 rounded-lg">
            <Clock className="w-6 h-6 text-yellow-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Upcoming</h3>
            <p className="text-2xl font-bold text-yellow-400">{upcomingTasks}</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass rounded-lg p-4"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-500 bg-opacity-20 rounded-lg">
            <AlertCircle className="w-6 h-6 text-red-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Overdue</h3>
            <p className="text-2xl font-bold text-red-400">{overdueTasks}</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}